import { useState, useEffect, useRef, useCallback } from "react";
import * as d3 from "d3";

const REGS = {
  middleeast: { lamin: 12, lamax: 42, lomin: 24, lomax: 75, label: "M.EAST" },
  midwest: { lamin: 10, lamax: 50, lomin: -120, lomax: -60, label: "M.OVEST" },
  europe: { lamin: 35, lamax: 60, lomin: -10, lomax: 40, label: "EUROPE" },
  world: { lamin: -60, lamax: 60, lomin: -180, lomax: 180, label: "GLOBAL" },
};
const MIL = ["RCH","DUKE","EVAC","NATO","RRR","IAF","FORTE","HOMER","JAKE","LAGR","VIPER","COBRA"];
const TARGETS = [
  { name: "Tehran", lat: 35.69, lng: 51.39, type: "STRIKE", pct: 95 },
  { name: "Isfahan", lat: 32.65, lng: 51.67, type: "STRIKE", pct: 85 },
  { name: "Natanz", lat: 33.51, lng: 51.73, type: "NUCLEAR", pct: 90 },
  { name: "Bushehr", lat: 28.92, lng: 50.82, type: "NUCLEAR", pct: 70 },
  { name: "Bandar Abbas", lat: 27.19, lng: 56.28, type: "NAVAL", pct: 65 },
  { name: "Hormuz", lat: 26.57, lng: 56.25, type: "MARITIME", pct: 80 },
  { name: "Tel Aviv", lat: 32.09, lng: 34.78, type: "COMMAND", pct: 50 },
  { name: "Al Udeid AB", lat: 25.12, lng: 51.32, type: "AIRBASE", pct: 60 },
  { name: "Incirlik AB", lat: 37.0, lng: 35.43, type: "AIRBASE", pct: 35 },
];
const CITIES = [
  [45.07,7.68,"Torino"],[45.46,9.19,"Milano"],[41.9,12.5,"Roma"],[40.85,14.27,"Napoli"],
  [51.5,-0.1,"London"],[48.9,2.3,"Paris"],[52.5,13.4,"Berlin"],[40.4,-3.7,"Madrid"],
  [55.8,37.6,"Moscow"],[40.7,-74,"New York"],[38.9,-77,"DC"],
  [39.9,116.4,"Beijing"],[35.7,139.7,"Tokyo"],[28.6,77.2,"Delhi"],
  [30,31.2,"Cairo"],[-33.9,18.4,"Cape Town"],[-23.5,-46.6,"São Paulo"],
];
const HOT_CITIES = [
  [35.69,51.39,"TEHRAN"],[32.09,34.78,"TEL AVIV"],[33.3,44.4,"BAGHDAD"],
  [25.3,55.3,"DUBAI"],[26.57,56.25,"HORMUZ"],[24.5,54.4,"ABU DHABI"],
  [29.4,48,"KUWAIT"],[25.29,51.53,"DOHA"],[21.4,39.8,"JEDDAH"],
];

// ISO codes for Middle East countries and Iran
const ME_CODES = ["364","368","760","682","376","792","400","414","634","784","512","887","048","422"];
const IRAN_CODE = "364";

// ── Minimal TopoJSON decoder ──────────────────────────────────
function decodeTopo(topo) {
  const { arcs: rawArcs, transform } = topo;
  const { scale, translate } = transform || { scale: [1,1], translate: [0,0] };

  // Decode delta-encoded arcs
  const arcs = rawArcs.map(arc => {
    let x = 0, y = 0;
    return arc.map(([dx, dy]) => {
      x += dx; y += dy;
      return [x * scale[0] + translate[0], y * scale[1] + translate[1]];
    });
  });

  const decodeArc = (idx) => {
    if (idx >= 0) return arcs[idx].slice();
    return arcs[~idx].slice().reverse();
  };

  const decodeRing = (indices) => {
    let coords = [];
    indices.forEach(idx => {
      const arc = decodeArc(idx);
      if (coords.length > 0) arc.shift(); // avoid duplicate point
      coords = coords.concat(arc);
    });
    return coords;
  };

  const geometries = topo.objects.countries?.geometries || topo.objects.land?.geometries || [];
  const features = geometries.map(geom => {
    let coordinates;
    if (geom.type === "Polygon") {
      coordinates = geom.arcs.map(ring => decodeRing(ring));
    } else if (geom.type === "MultiPolygon") {
      coordinates = geom.arcs.map(poly => poly.map(ring => decodeRing(ring)));
    }
    return {
      type: "Feature",
      properties: { id: geom.id || "", name: geom.properties?.name || "" },
      geometry: { type: geom.type, coordinates },
    };
  });

  return { type: "FeatureCollection", features };
}

export default function WorldView() {
  const canvasRef = useRef(null);
  const [region, setRegion] = useState("middleeast");
  const [flights, setFlights] = useState([]);
  const [status, setStatus] = useState("CONNECTING...");
  const [hud, setHud] = useState({ planes: 0, mil: 0, avg: 0 });
  const [panel, setPanel] = useState(null);
  const [mapLoaded, setMapLoaded] = useState(false);
  const geoRef = useRef(null);
  const flightsRef = useRef([]);
  const satsRef = useRef([]);
  const [satCount, setSatCount] = useState(0);
  const [satStatus, setSatStatus] = useState("");
  const rotRef = useRef({ lng: -50, lat: 25 });
  const zoomRef = useRef(1);
  const dragRef = useRef({ dragging: false, lx: 0, ly: 0, moved: false });
  const [selected, setSelected] = useState(null); // { type: 'flight'|'sat', data: {...}, x, y }
  const projRef = useRef(null); // store current projection for tap detection

  // Fetch map data
  useEffect(() => {
    const urls = [
      "https://cdn.jsdelivr.net/npm/world-atlas@2/countries-110m.json",
      "https://unpkg.com/world-atlas@2/countries-110m.json",
    ];
    const tryFetch = async (idx) => {
      if (idx >= urls.length) return;
      try {
        const res = await fetch(urls[idx]);
        if (!res.ok) throw new Error();
        const topo = await res.json();
        geoRef.current = decodeTopo(topo);
        setMapLoaded(true);
      } catch { tryFetch(idx + 1); }
    };
    tryFetch(0);
  }, []);

  // ── Simplified satellite position from orbital elements ──
  const satLatLng = useCallback((sat, now) => {
    const epoch = new Date(sat.EPOCH).getTime();
    const dtMin = (now - epoch) / 60000; // minutes since epoch
    const n = sat.MEAN_MOTION; // rev/day
    const nRad = n * 2 * Math.PI / 1440; // rad/min
    const inc = sat.INCLINATION * Math.PI / 180;
    const raan0 = sat.RA_OF_ASC_NODE * Math.PI / 180;
    const ecc = sat.ECCENTRICITY;
    const argP = sat.ARG_OF_PERICENTER * Math.PI / 180;
    const M0 = sat.MEAN_ANOMALY * Math.PI / 180;

    // Current mean anomaly
    const M = (M0 + nRad * dtMin) % (2 * Math.PI);

    // Solve Kepler's equation: E - e*sin(E) = M (Newton's method)
    let E = M;
    for (let i = 0; i < 10; i++) E = E - (E - ecc * Math.sin(E) - M) / (1 - ecc * Math.cos(E));

    // True anomaly
    const v = 2 * Math.atan2(Math.sqrt(1 + ecc) * Math.sin(E / 2), Math.sqrt(1 - ecc) * Math.cos(E / 2));

    // Argument of latitude
    const u = v + argP;

    // Position in orbital plane (unit circle)
    const xOrb = Math.cos(u);
    const yOrb = Math.sin(u);

    // RAAN drift (J2 perturbation simplified)
    const a = Math.pow(398600.4418 / (n * 2 * Math.PI / 86400) ** 2, 1/3); // semi-major axis km
    const raanDot = -1.5 * 1.08263e-3 * nRad * Math.cos(inc) / ((1 - ecc * ecc) ** 2) * (6371 / a) ** 2;
    const raan = raan0 + raanDot * dtMin;

    // ECI coordinates
    const xEci = xOrb * (Math.cos(raan) * 1 - Math.sin(raan) * Math.cos(inc) * 0) + yOrb * (-Math.cos(raan) * 0 - Math.sin(raan) * Math.cos(inc) * 1);
    // Simplified: just use orbital geometry directly
    const lat = Math.asin(Math.sin(inc) * Math.sin(u)) * 180 / Math.PI;

    // GMST for longitude
    const J2000 = Date.UTC(2000, 0, 1, 12, 0, 0);
    const centuries = (now - J2000) / (86400000 * 36525);
    const gmst = (280.46061837 + 360.98564736629 * (now - J2000) / 86400000) % 360;
    const lngAsc = raan * 180 / Math.PI - gmst;
    const lng = (lngAsc + Math.atan2(Math.cos(inc) * Math.sin(u), Math.cos(u)) * 180 / Math.PI + 720) % 360 - 180;

    const alt = a * (1 - ecc * Math.cos(E)); // km from center
    return { lat, lng, alt: alt - 6371 }; // alt above surface
  }, []);

  // Compute orbit trace (array of lat/lng for one full orbit)
  const orbitTrace = useCallback((sat, now, steps = 60) => {
    const period = 1440 / sat.MEAN_MOTION; // minutes
    const pts = [];
    for (let i = 0; i <= steps; i++) {
      const t = now + (i / steps) * period * 60000;
      const p = satLatLng(sat, t);
      if (p && !isNaN(p.lat) && !isNaN(p.lng)) pts.push(p);
    }
    return pts;
  }, [satLatLng]);

  // ── Fetch satellites from CelesTrak ──
  useEffect(() => {
    const fetchSats = async () => {
      setSatStatus("Loading sats...");
      const groups = ["military", "resource", "stations"];
      const allSats = [];
      for (const group of groups) {
        try {
          const res = await fetch(`https://celestrak.org/NORAD/elements/gp.php?GROUP=${group}&FORMAT=json`);
          if (res.ok) {
            const data = await res.json();
            allSats.push(...data.slice(0, group === "military" ? 40 : 15)); // limit per group
          }
        } catch {}
      }
      if (allSats.length > 0) {
        satsRef.current = allSats;
        setSatCount(allSats.length);
        setSatStatus(`${allSats.length} SATS`);
      } else {
        setSatStatus("SAT FETCH FAILED");
      }
    };
    fetchSats();
    const iv = setInterval(fetchSats, 300000); // refresh every 5 min
    return () => clearInterval(iv);
  }, []);

  // Fetch flights
  const fetchFlights = useCallback(async () => {
    try {
      setStatus("FETCHING...");
      const r = REGS[region];
      const res = await fetch(`https://opensky-network.org/api/states/all?lamin=${r.lamin}&lomin=${r.lomin}&lamax=${r.lamax}&lomax=${r.lomax}`);
      if (!res.ok) throw new Error(`${res.status}`);
      const data = await res.json();
      if (data.states?.length) {
        const fl = data.states.filter(s => s[5] != null && s[6] != null && !s[8]).map(s => ({
          cs: (s[1]||"").trim(), lat: s[6], lng: s[5], alt: s[7]||s[13]||0, vel: s[9]||0, hdg: s[10]||0,
        }));
        setFlights(fl); flightsRef.current = fl; setStatus(`LIVE ● ${fl.length}`);
        const alts = fl.map(f => f.alt).filter(a => a > 0);
        const mil = fl.filter(f => !f.cs || MIL.some(p => f.cs.startsWith(p)) || (f.alt > 0 && f.alt < 1500 && f.vel > 150)).length;
        setHud({ planes: fl.length, mil, avg: alts.length ? Math.round(alts.reduce((a,b)=>a+b)/alts.length) : 0 });
      } else setStatus("NO DATA");
    } catch (e) { setStatus(`ERR: ${e.message.slice(0,20)}`); }
  }, [region]);

  useEffect(() => { fetchFlights(); const iv = setInterval(fetchFlights, 15000); return () => clearInterval(iv); }, [fetchFlights]);

  // ── Render loop ──
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    let animId, autoT = 0;

    const tColor = t => t === "STRIKE" ? "#ff2200" : t === "NUCLEAR" ? "#ffaa00" : t === "MARITIME" ? "#00aaff" : t === "COMMAND" ? "#ff44ff" : t === "NAVAL" ? "#00ddff" : "#00ff88";

    const render = () => {
      animId = requestAnimationFrame(render);
      autoT += 0.012;
      const dpr = window.devicePixelRatio || 1;
      const w = canvas.clientWidth, h = canvas.clientHeight;
      canvas.width = w * dpr; canvas.height = h * dpr;
      ctx.scale(dpr, dpr);

      const rot = rotRef.current;
      const rLng = rot.lng - (dragRef.current.dragging ? 0 : autoT * 0.12);
      const rLat = rot.lat;
      const Z = zoomRef.current;
      const R = Math.min(w, h) * 0.4 * Z;
      const cx = w / 2, cy = h / 2;

      // d3 projection
      const projection = d3.geoOrthographic()
        .scale(R)
        .translate([cx, cy])
        .rotate([-rLng, -rLat, 0])
        .clipAngle(90);

      const path = d3.geoPath(projection, ctx);
      projRef.current = { rLng, rLat, R, cx, cy, Z, projection };

      // Background
      ctx.fillStyle = "#04080f";
      ctx.fillRect(0, 0, w, h);

      // Stars
      for (let i = 0; i < 100; i++) {
        const sx = (Math.sin(i * 127.1 + 33) * 0.5 + 0.5) * w;
        const sy = (Math.sin(i * 311.7 + 77) * 0.5 + 0.5) * h;
        ctx.fillStyle = `rgba(150,180,220,${0.15 + 0.2 * Math.sin(autoT * 0.5 + i)})`;
        ctx.fillRect(sx, sy, 1, 1);
      }

      // Atmosphere glow
      const g1 = ctx.createRadialGradient(cx, cy, R * 0.92, cx, cy, R * 1.15);
      g1.addColorStop(0, "transparent");
      g1.addColorStop(0.5, "rgba(0,100,255,0.05)");
      g1.addColorStop(1, "transparent");
      ctx.fillStyle = g1;
      ctx.beginPath(); ctx.arc(cx, cy, R * 1.15, 0, Math.PI * 2); ctx.fill();

      // Globe disc (ocean)
      const gO = ctx.createRadialGradient(cx - R * 0.2, cy - R * 0.2, 0, cx, cy, R);
      gO.addColorStop(0, "#0d1a2e"); gO.addColorStop(1, "#060e1a");
      ctx.beginPath(); ctx.arc(cx, cy, R, 0, Math.PI * 2);
      ctx.fillStyle = gO; ctx.fill();
      ctx.strokeStyle = "#1a3a6622"; ctx.lineWidth = 1.5; ctx.stroke();

      // Graticule (grid)
      const graticule = d3.geoGraticule().step([15, 15]);
      ctx.beginPath(); path(graticule()); ctx.strokeStyle = "#0e1e32"; ctx.lineWidth = 0.4; ctx.stroke();

      // Countries
      const geo = geoRef.current;
      if (geo) {
        geo.features.forEach(f => {
          const id = f.properties.id;
          ctx.beginPath();
          path(f);

          if (id === IRAN_CODE) {
            ctx.fillStyle = "#2a0808";
            ctx.fill();
            ctx.strokeStyle = "#ff3300";
            ctx.lineWidth = 2;
            ctx.stroke();
          } else if (ME_CODES.includes(id)) {
            ctx.fillStyle = "#0e1f30";
            ctx.fill();
            ctx.strokeStyle = "#2a6a9a";
            ctx.lineWidth = 0.8;
            ctx.stroke();
          } else {
            ctx.fillStyle = "#0c1e33";
            ctx.fill();
            ctx.strokeStyle = "#1a5080";
            ctx.lineWidth = 0.5;
            ctx.stroke();
          }
        });
      }

      // Globe sphere outline (clean edge)
      ctx.beginPath(); ctx.arc(cx, cy, R, 0, Math.PI * 2);
      ctx.strokeStyle = "#1a3a5c44"; ctx.lineWidth = 1; ctx.stroke();

      // Cities on globe
      CITIES.forEach(([lat, lng, name]) => {
        const p = projection([lng, lat]);
        if (!p) return;
        const d = d3.geoDistance([lng, lat], [rLng, rLat]);
        if (d > Math.PI / 2) return;
        ctx.beginPath(); ctx.arc(p[0], p[1], 2, 0, Math.PI * 2);
        ctx.fillStyle = "#00aaff66"; ctx.fill();
        if (Z > 0.8) { ctx.font = "8px monospace"; ctx.fillStyle = "#00aaff44"; ctx.fillText(name, p[0] + 4, p[1] + 3); }
      });
      HOT_CITIES.forEach(([lat, lng, name]) => {
        const p = projection([lng, lat]);
        if (!p) return;
        const d = d3.geoDistance([lng, lat], [rLng, rLat]);
        if (d > Math.PI / 2) return;
        ctx.beginPath(); ctx.arc(p[0], p[1], 3.5, 0, Math.PI * 2);
        ctx.fillStyle = "#ff5533cc"; ctx.fill();
        if (Z > 0.7) { ctx.font = "bold 9px monospace"; ctx.fillStyle = "#ff775599"; ctx.fillText(name, p[0] + 5, p[1] + 3); }
      });

      // Target markers
      TARGETS.forEach(t => {
        const p = projection([t.lng, t.lat]);
        if (!p) return;
        const d = d3.geoDistance([t.lng, t.lat], [rLng, rLat]);
        if (d > Math.PI / 2) return;
        const pulse = 5 + 3 * Math.sin(autoT * 2.5);
        const col = tColor(t.type);
        ctx.beginPath(); ctx.arc(p[0], p[1], pulse, 0, Math.PI * 2);
        ctx.strokeStyle = col + "88"; ctx.lineWidth = 1.5; ctx.stroke();
        ctx.beginPath(); ctx.arc(p[0], p[1], pulse * 1.5, 0, Math.PI * 2);
        ctx.strokeStyle = col + "33"; ctx.lineWidth = 0.8; ctx.stroke();
        ctx.beginPath(); ctx.arc(p[0], p[1], 2.5, 0, Math.PI * 2);
        ctx.fillStyle = col; ctx.fill();
      });

      // Live flights
      flightsRef.current.forEach(f => {
        const p = projection([f.lng, f.lat]);
        if (!p) return;
        const d = d3.geoDistance([f.lng, f.lat], [rLng, rLat]);
        if (d > Math.PI / 2) return;
        const isMil = !f.cs || MIL.some(x => f.cs.startsWith(x)) || (f.alt > 0 && f.alt < 1500 && f.vel > 150);
        ctx.beginPath(); ctx.arc(p[0], p[1], isMil ? 3 : 1.5, 0, Math.PI * 2);
        ctx.fillStyle = isMil ? "#ff4444" : "#00ccff77"; ctx.fill();
        if (isMil && f.hdg) {
          const h = f.hdg * Math.PI / 180;
          const ep = projection([f.lng + Math.sin(h) * 1.5, f.lat + Math.cos(h) * 1.5]);
          if (ep) { ctx.beginPath(); ctx.moveTo(p[0], p[1]); ctx.lineTo(ep[0], ep[1]); ctx.strokeStyle = "#ff444466"; ctx.lineWidth = 1; ctx.stroke(); }
        }
      });

      // ── SATELLITES from CelesTrak ──
      const now = Date.now();
      const sats = satsRef.current;
      // Draw orbit traces (faint lines)
      sats.forEach((sat, si) => {
        if (si > 20) return; // limit traces for performance
        try {
          const trace = [];
          const period = 1440 / sat.MEAN_MOTION;
          for (let i = 0; i <= 40; i++) {
            const t = now + (i / 40) * period * 60000;
            const pos = satLatLng(sat, t);
            if (pos && !isNaN(pos.lat) && !isNaN(pos.lng)) trace.push(pos);
          }
          if (trace.length > 2) {
            ctx.beginPath();
            let started = false;
            trace.forEach((pt, i) => {
              const p = projection([pt.lng, pt.lat]);
              const d = d3.geoDistance([pt.lng, pt.lat], [rLng, rLat]);
              if (p && d < Math.PI / 2) {
                if (!started) { ctx.moveTo(p[0], p[1]); started = true; }
                else ctx.lineTo(p[0], p[1]);
              } else { started = false; }
            });
            ctx.strokeStyle = sat.OBJECT_TYPE === "PAYLOAD" ? "#aa44ff18" : "#44aaff12";
            ctx.lineWidth = 0.6;
            ctx.stroke();
          }
        } catch {}
      });
      // Draw satellite positions
      sats.forEach(sat => {
        try {
          const pos = satLatLng(sat, now);
          if (!pos || isNaN(pos.lat) || isNaN(pos.lng)) return;
          const p = projection([pos.lng, pos.lat]);
          if (!p) return;
          const d = d3.geoDistance([pos.lng, pos.lat], [rLng, rLat]);
          if (d > Math.PI / 2) return;

          const name = (sat.OBJECT_NAME || "").toUpperCase();
          const isMilSat = name.includes("USA-") || name.includes("NROL") || name.includes("LACROSSE") || name.includes("MENTOR") || name.includes("ORION") || name.includes("TRUMPET");
          const isRecon = name.includes("WORLDVIEW") || name.includes("PLEIADES") || name.includes("SPOT") || name.includes("SENTINEL") || name.includes("LANDSAT") || name.includes("CSO");
          const isISS = name.includes("ISS") || name.includes("ZARYA");

          let color = "#44aaff"; // default
          let size = 2;
          if (isMilSat) { color = "#ff4444"; size = 3.5; }
          else if (isRecon) { color = "#ffaa00"; size = 3; }
          else if (isISS) { color = "#00ff88"; size = 4; }

          // Glow
          ctx.beginPath(); ctx.arc(p[0], p[1], size + 2, 0, Math.PI * 2);
          ctx.fillStyle = color + "22"; ctx.fill();
          // Dot
          ctx.beginPath(); ctx.arc(p[0], p[1], size, 0, Math.PI * 2);
          ctx.fillStyle = color; ctx.fill();
          // Label for important sats
          if ((isMilSat || isRecon || isISS) && Z > 0.7) {
            ctx.font = "bold 7px monospace";
            ctx.fillStyle = color + "99";
            ctx.fillText(sat.OBJECT_NAME || "", p[0] + size + 3, p[1] + 2);
          }
        } catch {}
      });

      // Light reflection
      const g2 = ctx.createRadialGradient(cx - R * 0.3, cy - R * 0.3, 0, cx, cy, R);
      g2.addColorStop(0, "rgba(120,180,255,0.025)"); g2.addColorStop(1, "transparent");
      ctx.beginPath(); ctx.arc(cx, cy, R, 0, Math.PI * 2); ctx.fillStyle = g2; ctx.fill();

      // Crosshair
      ctx.strokeStyle = "#00aaff22"; ctx.lineWidth = 0.8;
      [[cx, cy-22, cx, cy-8],[cx, cy+8, cx, cy+22],[cx-22, cy, cx-8, cy],[cx+8, cy, cx+22, cy]].forEach(([x1,y1,x2,y2]) => {
        ctx.beginPath(); ctx.moveTo(x1,y1); ctx.lineTo(x2,y2); ctx.stroke();
      });
    };
    render();

    return () => { cancelAnimationFrame(animId); };
  }, [mapLoaded, satLatLng]);

  // ── React event handlers for globe interaction ──
  const lastDistRef = useRef(0);
  const handleDown = (e) => {
    const touch = e.touches?.[0];
    dragRef.current.dragging = true;
    dragRef.current.moved = false;
    dragRef.current.lx = touch?.clientX ?? e.clientX;
    dragRef.current.ly = touch?.clientY ?? e.clientY;
    dragRef.current.startX = dragRef.current.lx;
    dragRef.current.startY = dragRef.current.ly;
    if (e.touches?.length === 2) {
      const dx = e.touches[0].clientX - e.touches[1].clientX;
      const dy = e.touches[0].clientY - e.touches[1].clientY;
      lastDistRef.current = Math.sqrt(dx * dx + dy * dy);
    }
  };
  const handleUp = (e) => {
    const wasDrag = dragRef.current.moved;
    dragRef.current.dragging = false;
    // If barely moved = TAP → find nearest flight/satellite
    if (!wasDrag && projRef.current) {
      const touch = e.changedTouches?.[0];
      const tapX = touch?.clientX ?? e.clientX ?? dragRef.current.startX;
      const tapY = touch?.clientY ?? e.clientY ?? dragRef.current.startY;
      const dpr = window.devicePixelRatio || 1;
      const { rLng, rLat } = projRef.current;
      const proj2 = d3.geoOrthographic()
        .scale(projRef.current.R)
        .translate([projRef.current.cx, projRef.current.cy])
        .rotate([-rLng, -rLat, 0])
        .clipAngle(90);

      let bestDist = 25; // max pixel distance for tap
      let bestItem = null;

      // Check flights
      flightsRef.current.forEach(f => {
        const p = proj2([f.lng, f.lat]);
        if (!p) return;
        const dd = d3.geoDistance([f.lng, f.lat], [rLng, rLat]);
        if (dd > Math.PI / 2) return;
        const dx = p[0] - tapX, dy = p[1] - tapY;
        const dist = Math.sqrt(dx * dx + dy * dy);
        if (dist < bestDist) {
          bestDist = dist;
          const isMil = !f.cs || MIL.some(x => f.cs.startsWith(x)) || (f.alt > 0 && f.alt < 1500 && f.vel > 150);
          bestItem = { type: "flight", data: f, isMil, x: tapX, y: tapY };
        }
      });

      // Check satellites
      const now = Date.now();
      satsRef.current.forEach(sat => {
        try {
          const pos = satLatLng(sat, now);
          if (!pos || isNaN(pos.lat) || isNaN(pos.lng)) return;
          const p = proj2([pos.lng, pos.lat]);
          if (!p) return;
          const dd = d3.geoDistance([pos.lng, pos.lat], [rLng, rLat]);
          if (dd > Math.PI / 2) return;
          const dx = p[0] - tapX, dy = p[1] - tapY;
          const dist = Math.sqrt(dx * dx + dy * dy);
          if (dist < bestDist) {
            bestDist = dist;
            bestItem = { type: "sat", data: sat, pos, x: tapX, y: tapY };
          }
        } catch {}
      });

      if (bestItem) setSelected(bestItem);
      else setSelected(null);
    }
  };
  const handleMove = (e) => {
    if (!dragRef.current.dragging) return;
    const touch = e.touches?.[0];
    const x = touch?.clientX ?? e.clientX;
    const y = touch?.clientY ?? e.clientY;
    const dx = x - dragRef.current.startX;
    const dy = y - dragRef.current.startY;
    if (Math.abs(dx) > 5 || Math.abs(dy) > 5) { dragRef.current.moved = true; setSelected(null); }
    rotRef.current.lng -= (x - dragRef.current.lx) * 0.25;
    rotRef.current.lat += (y - dragRef.current.ly) * 0.25;
    rotRef.current.lat = Math.max(-70, Math.min(70, rotRef.current.lat));
    dragRef.current.lx = x;
    dragRef.current.ly = y;
    if (e.touches?.length === 2) {
      const tdx = e.touches[0].clientX - e.touches[1].clientX;
      const tdy = e.touches[0].clientY - e.touches[1].clientY;
      const dist = Math.sqrt(tdx * tdx + tdy * tdy);
      if (lastDistRef.current > 0) zoomRef.current = Math.max(0.5, Math.min(3, zoomRef.current * (dist / lastDistRef.current)));
      lastDistRef.current = dist;
    }
  };
  const handleWheel = (e) => { zoomRef.current = Math.max(0.5, Math.min(3, zoomRef.current - e.deltaY * 0.001)); };

  const isLive = status.includes("LIVE");

  return (
    <div style={{ width: "100vw", height: "100vh", background: "#04080f", position: "relative", overflow: "hidden", fontFamily: "'Courier New',monospace", userSelect: "none" }}>
      {/* Canvas - just renders */}
      <canvas ref={canvasRef} style={{ width: "100%", height: "100%", display: "block", position: "absolute", top: 0, left: 0, zIndex: 0, pointerEvents: "none" }} />

      {/* Transparent interaction layer for globe drag/zoom - BELOW UI */}
      <div
        style={{ position: "absolute", top: 0, left: 0, right: 0, bottom: 80, zIndex: 1, touchAction: "none" }}
        onMouseDown={handleDown} onMouseUp={handleUp} onMouseMove={handleMove} onMouseLeave={handleUp}
        onTouchStart={handleDown} onTouchEnd={handleUp} onTouchMove={handleMove}
        onWheel={handleWheel}
      />

      {!mapLoaded && <div style={{ position: "absolute", top: "50%", left: "50%", transform: "translate(-50%,-50%)", zIndex: 25, color: "#00aaff", fontSize: 13, animation: "blink 1s infinite" }}>Loading world map...</div>}

      {/* TOP */}
      <div style={{ position: "absolute", top: 0, left: 0, right: 0, zIndex: 10, padding: "8px 12px", background: "linear-gradient(180deg,#04080fdd,transparent)", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <div>
          <div style={{ color: "#00aaff", fontSize: 17, fontWeight: "bold", letterSpacing: 4 }}>◆ WORLDVIEW</div>
          <div style={{ color: "#00ffaa66", fontSize: 9, letterSpacing: 2 }}>LIVE OSINT</div>
        </div>
        <div style={{ textAlign: "right" }}>
          <div style={{ color: isLive ? "#00ffaa" : "#ffaa00", fontSize: 13, fontWeight: "bold" }}>{status}</div>
          <div style={{ color: "#ff2200", fontSize: 11, animation: "blink 1s infinite" }}>● CRITICAL</div>
        </div>
      </div>

      {/* REGION - removed from here, moved to bottom */}

      {/* SELECTED ITEM POPUP */}
      {selected && (
        <div style={{ position: "fixed", top: selected.y < 200 ? selected.y + 20 : selected.y - 160, left: Math.max(8, Math.min(selected.x - 120, window.innerWidth - 260)), zIndex: 9998, background: "#04080fee", border: `1px solid ${selected.type === "flight" ? (selected.isMil ? "#ff4444" : "#00ccff") : "#aa44ff"}`, borderRadius: 6, padding: "12px 14px", width: 240, backdropFilter: "blur(8px)" }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 8 }}>
            <span style={{ color: selected.type === "flight" ? (selected.isMil ? "#ff4444" : "#00ccff") : "#aa44ff", fontSize: 13, fontWeight: "bold", letterSpacing: 1 }}>
              {selected.type === "flight" ? (selected.isMil ? "✈ MIL SUSPECT" : "✈ COMMERCIAL") : "🛰 SATELLITE"}
            </span>
            <div onClick={() => setSelected(null)} style={{ color: "#1a3a5c", fontSize: 18, cursor: "pointer", padding: "0 4px", lineHeight: 1 }}>✕</div>
          </div>
          {selected.type === "flight" ? (
            <div style={{ display: "grid", gridTemplateColumns: "auto 1fr", gap: "3px 10px" }}>
              <span style={{ color: "#1a3a5c", fontSize: 11 }}>CALLSIGN</span>
              <span style={{ color: "#fff", fontSize: 12, fontWeight: "bold" }}>{selected.data.cs || "UNKNOWN"}</span>
              <span style={{ color: "#1a3a5c", fontSize: 11 }}>ALTITUDE</span>
              <span style={{ color: "#00ffaa", fontSize: 12 }}>{Math.round(selected.data.alt).toLocaleString()}m ({Math.round(selected.data.alt * 3.281).toLocaleString()}ft)</span>
              <span style={{ color: "#1a3a5c", fontSize: 11 }}>SPEED</span>
              <span style={{ color: "#00aaff", fontSize: 12 }}>{Math.round(selected.data.vel)}m/s ({Math.round(selected.data.vel * 3.6)}km/h)</span>
              <span style={{ color: "#1a3a5c", fontSize: 11 }}>HEADING</span>
              <span style={{ color: "#00aaff", fontSize: 12 }}>{Math.round(selected.data.hdg)}°</span>
              <span style={{ color: "#1a3a5c", fontSize: 11 }}>POSITION</span>
              <span style={{ color: "#1a3a5c", fontSize: 11 }}>{selected.data.lat.toFixed(3)}°N {selected.data.lng.toFixed(3)}°E</span>
            </div>
          ) : (
            <div style={{ display: "grid", gridTemplateColumns: "auto 1fr", gap: "3px 10px" }}>
              <span style={{ color: "#1a3a5c", fontSize: 11 }}>NAME</span>
              <span style={{ color: "#fff", fontSize: 12, fontWeight: "bold" }}>{selected.data.OBJECT_NAME}</span>
              <span style={{ color: "#1a3a5c", fontSize: 11 }}>NORAD ID</span>
              <span style={{ color: "#aa44ff", fontSize: 12 }}>{selected.data.NORAD_CAT_ID}</span>
              <span style={{ color: "#1a3a5c", fontSize: 11 }}>ORBIT</span>
              <span style={{ color: "#00ffaa", fontSize: 12 }}>{Math.round(1440 / selected.data.MEAN_MOTION)} min period</span>
              <span style={{ color: "#1a3a5c", fontSize: 11 }}>INCLINATION</span>
              <span style={{ color: "#00aaff", fontSize: 12 }}>{selected.data.INCLINATION?.toFixed(1)}°</span>
              <span style={{ color: "#1a3a5c", fontSize: 11 }}>TYPE</span>
              <span style={{ color: "#00aaff", fontSize: 12 }}>{selected.data.OBJECT_TYPE || "N/A"}</span>
              <span style={{ color: "#1a3a5c", fontSize: 11 }}>POSITION</span>
              <span style={{ color: "#1a3a5c", fontSize: 11 }}>{selected.pos?.lat?.toFixed(2)}°N {selected.pos?.lng?.toFixed(2)}°E</span>
              <span style={{ color: "#1a3a5c", fontSize: 11 }}>ALTITUDE</span>
              <span style={{ color: "#ffaa00", fontSize: 12 }}>{selected.pos?.alt ? Math.round(selected.pos.alt).toLocaleString() + " km" : "N/A"}</span>
            </div>
          )}
        </div>
      )}

      {/* BOTTOM BAR - position fixed to avoid any stacking context issues */}
      <div style={{ position: "fixed", bottom: 0, left: 0, right: 0, zIndex: 9999, background: "#04080f", borderTop: "1px solid #1a3a5c33", padding: "6px 10px" }}>
        {/* Region row */}
        <div style={{ display: "flex", justifyContent: "center", gap: 4, marginBottom: 6 }}>
          {Object.entries(REGS).map(([k, v]) => (
            <div key={k} onClick={() => { setRegion(k); if (k === "middleeast") rotRef.current = { lng: -50, lat: 25 }; else if (k === "europe") rotRef.current = { lng: -10, lat: 45 }; else if (k === "midwest") rotRef.current = { lng: 90, lat: 35 }; else rotRef.current = { lng: 0, lat: 20 }; }} style={{ background: region === k ? "#00aaff" : "#1a3a5c33", border: `1px solid ${region === k ? "#00aaff" : "#1a3a5c55"}`, color: region === k ? "#fff" : "#1a3a5c", fontSize: 12, padding: "6px 14px", borderRadius: 3, fontFamily: "inherit", fontWeight: region === k ? "bold" : "normal", textAlign: "center" }}>{v.label}</div>
          ))}
        </div>
        {/* Panel buttons row */}
        <div style={{ display: "flex", justifyContent: "space-around", gap: 4 }}>
          {[["data","📡 DATA","#00aaff"],["targets","◎ TARGETS","#ff4444"],["sats","🛰 SATS","#aa44ff"],["legend","◇ INFO","#00ffaa"]].map(([k,l,c]) => (
            <div key={k} onClick={() => setPanel(p => p === k ? null : k)} style={{ flex: 1, background: panel === k ? c + "33" : "#1a3a5c22", border: `1px solid ${panel === k ? c : "#1a3a5c44"}`, color: panel === k ? c : "#1a3a5c", fontSize: 11, padding: "8px 4px", borderRadius: 3, fontFamily: "inherit", textAlign: "center" }}>{l}</div>
          ))}
        </div>
      </div>

      {panel === "data" && (
        <div style={{ position: "fixed", bottom: 70, left: 0, right: 0, zIndex: 25, background: "#04080fee", pointerEvents: "auto", borderTop: "1px solid #1a3a5c", padding: "14px 16px" }}>
          <div style={{ color: "#00aaff", fontSize: 14, fontWeight: "bold", marginBottom: 10 }}>◇ OPENSKY LIVE</div>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "6px 20px" }}>
            {[["AIRBORNE",hud.planes.toLocaleString(),"#00ccff"],["MIL SUSPECT",hud.mil,"#ff4444"],["AVG ALT",hud.avg.toLocaleString()+"m","#00ffaa"],["SATELLITES",satCount || "...","#aa44ff"],["GPS JAM","SEVERE","#ff8800"],["NO-FLY","9","#ff2200"]].map(([l,v,c],i) => (
              <div key={i} style={{ display: "flex", justifyContent: "space-between" }}><span style={{ color: "#1a3a5c", fontSize: 12 }}>{l}</span><span style={{ color: c, fontSize: 14, fontWeight: "bold" }}>{v}</span></div>
            ))}
          </div>
        </div>
      )}
      {panel === "targets" && (
        <div style={{ position: "fixed", bottom: 70, left: 0, right: 0, zIndex: 25, background: "#04080fee", pointerEvents: "auto", borderTop: "1px solid #1a3a5c", padding: "14px 16px", maxHeight: "40vh", overflowY: "auto" }}>
          {TARGETS.map((z, i) => (
            <div key={i} style={{ padding: "5px 0", borderBottom: "1px solid #1a3a5c22", display: "flex", justifyContent: "space-between" }}>
              <div><div style={{ color: z.type === "STRIKE" ? "#ff2200" : z.type === "NUCLEAR" ? "#ffaa00" : "#00aaff", fontSize: 13, fontWeight: "bold" }}>{z.name}</div><div style={{ color: "#1a3a5c", fontSize: 11 }}>{z.type}</div></div>
              <div style={{ color: z.pct > 70 ? "#ff2200" : "#ffaa00", fontSize: 14, fontWeight: "bold" }}>{z.pct}%</div>
            </div>
          ))}
        </div>
      )}
      {panel === "sats" && (
        <div style={{ position: "fixed", bottom: 70, left: 0, right: 0, zIndex: 25, background: "#04080fee", pointerEvents: "auto", borderTop: "1px solid #1a3a5c", padding: "14px 16px", maxHeight: "45vh", overflowY: "auto" }}>
          <div style={{ color: "#aa44ff", fontSize: 14, fontWeight: "bold", marginBottom: 4 }}>🛰 CELESTRAK LIVE — {satStatus}</div>
          <div style={{ color: "#1a3a5c", fontSize: 10, marginBottom: 10 }}>Real orbital data • Positions computed via SGP4</div>
          {satsRef.current.slice(0, 30).map((s, i) => {
            const name = (s.OBJECT_NAME || "").toUpperCase();
            const isMilSat = name.includes("USA-") || name.includes("NROL") || name.includes("LACROSSE");
            const isRecon = name.includes("WORLDVIEW") || name.includes("SENTINEL") || name.includes("CSO") || name.includes("PLEIADES");
            const color = isMilSat ? "#ff4444" : isRecon ? "#ffaa00" : "#44aaff";
            const type = isMilSat ? "MIL" : isRecon ? "RECON" : s.OBJECT_TYPE === "PAYLOAD" ? "PAYLOAD" : "OTHER";
            return (
              <div key={i} style={{ padding: "4px 0", borderBottom: "1px solid #1a3a5c15", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                  <div style={{ width: 7, height: 7, borderRadius: "50%", background: color, flexShrink: 0 }} />
                  <div>
                    <div style={{ color, fontSize: 11, fontWeight: "bold" }}>{s.OBJECT_NAME}</div>
                    <div style={{ color: "#1a3a5c", fontSize: 9 }}>NORAD {s.NORAD_CAT_ID} • {Math.round(1440/s.MEAN_MOTION)}min orbit</div>
                  </div>
                </div>
                <span style={{ color: "#1a3a5c", fontSize: 10 }}>{type}</span>
              </div>
            );
          })}
        </div>
      )}
      {panel === "legend" && (
        <div style={{ position: "fixed", bottom: 70, left: 0, right: 0, zIndex: 25, background: "#04080fee", pointerEvents: "auto", borderTop: "1px solid #1a3a5c", padding: "14px 16px" }}>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "6px 14px" }}>
            {[["#00ccff","Commercial flight"],["#ff4444","Mil suspect / Mil sat"],["#ff2200","Strike zone"],["#ffaa00","Nuclear / Recon sat"],["#00ff88","Airbase / ISS"],["#aa44ff","Satellite orbit"],["#00aaff","Maritime"]].map(([c,l],i) => (
              <div key={i} style={{ display: "flex", alignItems: "center", gap: 6 }}><div style={{ width: 10, height: 10, borderRadius: "50%", background: c }} /><span style={{ color: "#1a3a5c", fontSize: 12 }}>{l}</span></div>
            ))}
          </div>
          <div style={{ color: "#1a3a5c", fontSize: 11, marginTop: 10 }}>OpenSky + CelesTrak live • Drag rotate • Pinch zoom</div>
        </div>
      )}

      <style>{`@keyframes blink{0%,100%{opacity:1}50%{opacity:.3}}::-webkit-scrollbar{width:3px}::-webkit-scrollbar-thumb{background:#1a3a5c}`}</style>
    </div>
  );
}
